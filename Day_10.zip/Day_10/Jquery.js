$(document).ready(function(){
    
    $("#01").click(function(){
        $("#a1").hide(500);
        $(this).attr("disabled",true);
        $("#02").attr("enabled",true);
    });
    $("#02").click(function(){
        $("#a1").show(500);
        $(this).attr("disabled",true);
        $("#01").attr("enabled",true);

    });
    $("#03").click(function(){
        var IncSize= parseInt($("#a1").css("height"));

        if (IncSize<=500){
            IncSize+=50;
            $("#a1").css("height",IncSize);
            $("#a1").css("width", IncSize);
            $(this).attr("disabled",true);
            $("#04").attr("enabled",true);
        }
        else{
            alert("not possible to increase");
        }
    });
    $("#04").click(function(){
        var DecSize= parseInt($("#a1").css("height"));

        if (DecSize>=100){
            DecSize-=50;
            $("#a1").css("height",DecSize);
            $("#a1").css("width", DecSize);
            $(this).attr("disabled",true);
            $("#03").attr("enabled",true);

        }
        else{
            alert("not possible to decrease");
        }
    });
});

