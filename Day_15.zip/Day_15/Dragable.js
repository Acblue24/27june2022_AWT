$(document).ready(function(){
    $("#01").draggable();
    // $("#02").draggable();

    $("#02").droppable({
        accept: "#01",
        drop: function(event,ui){
            $(this).addlCass("").find("p").html("done.....");
        }
    });
});