
function Javascript1()
{
document.body.style.backgroundColor="green";
document.getElementById("1").style.backgroundColor="Aqua";
document.getElementById("2").style.backgroundColor=prompt("Enter your colour");
document.getElementById("3").style.backgroundColor="wheat";
// document.getElementsByClassName("Anu").style.backgroundColor=prompt("green")


alert('hello guys');
console.log('Anurag');
}
function Colourchange()
{
    // document.body.style.backgroundColor=document.getElementById("colour").value;
    document.getElementById("colour6").style.backgroundColor=document.getElementById("colour4").value;
}
function colour52(){

    var Ac=prompt("Enter your firstname")
    document.getElementById("id1").innerHTML=Ac;

    var Ac1=prompt("Enter your lastname")
    document.getElementById("id2").innerHTML=Ac1;
}
