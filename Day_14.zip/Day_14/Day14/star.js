
$(document).ready(function(){
  $('#01').draggable(
      {
          delay:3000
      }
  );
  $('#1').draggable({
      containment: "#02"
  });
  $('#03').draggable({
      axis: 'x'
  });
  $('#04').draggable({
      axis: 'y'
  });
  $('#05').draggable({
      helper: 'clone'
  });
  $('#06').draggable({
      holder: 'div1'
  });
});